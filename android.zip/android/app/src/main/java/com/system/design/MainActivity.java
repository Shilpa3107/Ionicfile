package com.system.design;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
